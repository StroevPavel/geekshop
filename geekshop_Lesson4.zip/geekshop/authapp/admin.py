from django.contrib import admin

from .models import ShopUser

admin.site.register(ShopUser)